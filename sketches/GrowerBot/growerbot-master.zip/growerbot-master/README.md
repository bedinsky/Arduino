this is the source for growerbot, a social gardening assistant. more details at growerbot.com
